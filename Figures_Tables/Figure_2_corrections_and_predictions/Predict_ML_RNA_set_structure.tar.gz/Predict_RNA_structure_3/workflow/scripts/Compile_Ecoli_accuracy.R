library(tidyverse)

####Make a list of files to read in####

v.folders = paste("resources/MaxExpect_Scores", list.files("resources/MaxExpect_Scores"), sep = "/")

v.files = c() 

for (i in v.folders) {
  files = paste(i, list.files(i), sep = "/")
  v.files = c(v.files, files)
}

####Function that reads in scores####

read.score = function(x){
  RNA = gsub(".txt", "", strsplit(x, split = "/")[[1]][4])                                    #1
  Program = strsplit(x, split = "/")[[1]][3]                                                  #2
  
  Con = file(x)
  Lines = readLines(Con)
  close(Con)
  
  Lines
  
  Accepted = gsub(" ", "", strsplit(Lines[1], split = ":")[[1]][2])                          #3
  Predicted = gsub(" ", "", strsplit(Lines[2], split = ":")[[1]][2])                         #4
  Sensitivity = as.numeric(gsub("%", "", strsplit(Lines[4], split = "= ")[[1]][2]))/100      #5
  PPV = as.numeric(gsub("%", "", strsplit(Lines[5], split = "= ")[[1]][2]))/100              #6
  Accuracy = sqrt(Sensitivity*PPV)                                                           #7
  
  df = data.frame(RNA, Program, Accepted, Predicted, Sensitivity, PPV, Accuracy)
}

####Read in scores####

l.df.score = lapply(v.files, read.score)

####Compile and write results####

df = bind_rows(l.df.score)

write.csv(df, "results/001_Accuracy.csv", row.names = F, na = "")