library(tidyverse)

####Make a list of files to read in####

v.folders = paste("resources/CTs", list.files("resources/CTs"), sep = "/")

v.files = c() 

for (i in v.folders) {
  files = paste(i, list.files(i), sep = "/")
  v.files = c(v.files, files)
}

####Function that counts structures####

read.n = function(x){
  Con = file(x)
  Lines = readLines(Con)
  close(Con)
  
  Lines
  RNA = gsub(".ct", "", strsplit(x, split = "/")[[1]][4])  #1
  Program = strsplit(x, split = "/")[[1]][3]               #2
  Structures = length(which(grepl("ENERGY", Lines)))       #3
  
  df = data.frame(RNA, Program, Structures)
}

####Read in scores####

l.df.n = lapply(v.files, read.n)

####Compile and write results####

df = bind_rows(l.df.n)

write.csv(df, "results/002_Substructures.csv", row.names = F, na = "")

