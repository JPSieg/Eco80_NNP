
list.files("resources/Structure_database")

df = read.csv("resources/main_index.csv")

head(df)

v.bps = paste("resources/Structure_database/", df$Set, "/", df$Index, ".bpseq", sep = "")
v.ct = paste("resources/Known_CTs/", df$ID, ".ct", sep = "")

pb = txtProgressBar(min = 1, max = nrow(df), initial = 1, style = 3)

for (i in 1:nrow(df)){
  setTxtProgressBar(pb, i)
  RNA = df$ID[i]
  df.i = read.delim(v.bps[i], sep = "", header = F)
  Lines = c(paste("  ", length(df.i$V1), "    ", RNA, sep = ""),
            paste(df.i$V1, df.i$V2, df.i$V1 - 1, df.i$V1 + 1, df.i$V3, df.i$V1, sep = "      "))
  Con = file(v.ct[i])
  writeLines(Lines, Con)
  close(Con)
}
