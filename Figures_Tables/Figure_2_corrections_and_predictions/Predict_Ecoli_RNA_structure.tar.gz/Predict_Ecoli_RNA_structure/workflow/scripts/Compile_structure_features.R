library(tidyverse)

####Make a list of files to read in####

v.folders = paste("resources/MaxExpect_CTs", list.files("resources/MaxExpect_CTs"), sep = "/")

v.files = c() 

for (i in v.folders) {
  files = paste(i, list.files(i), sep = "/")
  v.files = c(v.files, files)
}

####Function that counts structures####

read.ct = function(x){
  df = read.delim(x, sep = "", skip = 1, header = F)
  RNA = gsub(".ct", "", strsplit(x, split = "/")[[1]][4])  #1
  Program = strsplit(x, split = "/")[[1]][3]               #2
  
  Length = length(df$V1)                                   #3
  Paired.n = length(which(df$V5 != 0))                     #4
  Pairs = length(which(df$V5 != 0))/2                      #5
  
  GU = rep(F, nrow(df))
  AU = rep(F, nrow(df))
  GC = rep(F, nrow(df))
  
  for (i in 1:nrow(df)){
    if (df$V5[i] != 0){
      if (df$V2[i] == "A"){
        if (df$V2[df$V5[i]] %in% c("U")){
          AU[i] = T
        }
      }
      if (df$V2[i] == "C"){
        if (df$V2[df$V5[i]] %in% c("G")){
          GC[i] = T
        }
      }
      if (df$V2[i] == "G"){
        if (df$V2[df$V5[i]] %in% c("C")){
          GC[i] = T
        }
        if (df$V2[df$V5[i]] %in% c("U")){
          GU[i] = T
        }
      }
      if (df$V2[i] == "U"){
        if (df$V2[df$V5[i]] %in% c("A")){
          AU[i] = T
        }
        if (df$V2[df$V5[i]] %in% c("G")){
          GU[i] = T
        }
      }
    }
  }
  
  GU.pairs = length(which(GU))/2                           #6
  AU.pairs = length(which(AU))/2                           #7
  GC.pairs = length(which(GC))/2                           #8
  
  df = data.frame(RNA, Program, Length, Paired.n, Pairs, GU.pairs, AU.pairs, GC.pairs)
}

####Read in scores####

l.df.feature = lapply(v.files, read.ct)

####Compile and write results####

df = bind_rows(l.df.feature)

write.csv(df, "results/003_Structural_features.csv", row.names = F, na = "")

