library(R2easyR)
library(tidyverse)
library(RColorBrewer)
library(cowplot)
library(NatParksPalettes)

####Generate color pallets####

Bryce = natparks.pals("BryceCanyon", 9)

####Read in the index####

df.i = read.csv("resources/main_index.csv")

####Function that calculates Psss from a BBPM####

list.files()

read.BPPM = function(x = "Data/BPPM/1kcalmol_penalty_data_tables/E01.txt"){
  df = read.delim(x, skip = 1)
  df$PBP = 10^-df$X.log10.Probability.
  Con = file(x)
  ij = as.numeric(readLines(Con)[1])
  close(Con)
  M = matrix(nrow = ij, ncol = ij)
  for (i in 1:nrow(df)){
    M[df$i[i], df$j[i]] = df$PBP[i]
    M[df$j[i], df$i[i]] = df$PBP[i]
  }
  M[which(is.na(M))] = 0
  Pss = c()
  for (i in 1:nrow(M)){
    Pss[i] = 1 - sum(M[i,])
  }
  output = Pss
}

####Function that writes a FASTA and a R2R csv####

write_files = function(x = 1){
  ####Read in data####
  
  df = read.csv(paste("resources/R2easyR_csvs", df.i$Transcript[x], sep = "/"))
  
  ####R2easyR to make csvs####
  
  df = df %>% filter(N %in% df.i$Start[x]:df.i$End[x])
  #palette = rev(c("#0D47A1", "#1565C0", "#1976D2", "#1E88E5", "#2196F3", "#42A5F5", "#64B5F6", "#90CAF9", "#BBDEFB", "#E3F2FD"))
  palette = brewer.pal(9, "Blues")
  #####Make a list of PBPM and read them in####
  
  v.BPPM = paste("Data/BPPM/", list.files("Data/BPPM"), "/", df.i$RNA[x], ".txt", sep = "")
  
  l.Pss = lapply(v.BPPM, read.BPPM)
  
  l.df.compare = {}
  for (i in 1:length(v.BPPM)){
    df.1 = df %>% select(N, Nucleotide, N.1, N.1.1, BP, N.2, Dotbracket, Reactivity)
    df.1$Pss = l.Pss[[i]]
    df.1$Parameter = list.files("Data/BPPM")[i]
    l.df.compare[[i]] = df.1
  }
  df.compare = bind_rows(l.df.compare)
  
  df.compare$Parameter = factor(df.compare$Parameter,
         levels = c("UV_1MNaCl_data_tables",
                    "FDBI_1MNaCl_data_tables",
                    "1kcalmol_penalty_data_tables",
                    "FBDI_Eco80_data_tables"),
         labels = c("UV 1MNaCl",
                    "FDBI 1MNaCl",
                    "1.0 kcal/mol penalty",
                    "FBDI Eco80"))
  df.1M = df.compare %>% filter(Parameter %in% c("UV 1MNaCl"))
  df.Eco80 = df.compare %>% filter(Parameter %in% c("FBDI Eco80"))
  
  P = ggplot() +
    geom_point(data = df.compare %>% filter(Parameter %in% c("UV 1MNaCl", "FBDI Eco80")),
               mapping = aes(x = Pss, y = Reactivity, color = Parameter, shape = Parameter)) + 
    geom_segment(aes(x = df.1M$Pss, y = df.1M$Reactivity, xend = df.Eco80$Pss, yend = df.Eco80$Reactivity),
                 arrow = arrow(length = unit(0.5, "cm"))) +
    scale_color_manual(values = Bryce[c(1,5)]) +
    theme_classic() +
    theme(axis.text = element_text(color = "black"),
          legend.position = "Top",
          legend.title = element_blank()) +
    scale_x_continuous(limits = c(0.001, 1), trans = "log10")
  ggsave(paste("results/Plots/", df.i$RNA[x], ".svg", sep = ""), P, width = 1.5, height = 1.5, bg = "white", units = "in", scale = 1.75)
}

####Run the funtion####

for (i in 1:nrow(df.i)){
  write_files(i)
}
