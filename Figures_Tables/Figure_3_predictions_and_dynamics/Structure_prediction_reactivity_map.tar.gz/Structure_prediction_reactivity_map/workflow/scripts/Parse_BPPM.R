library(R2easyR)
library(tidyverse)
library(RColorBrewer)

####Read in the index####

df.i = read.csv("resources/main_index.csv")

####Function that calculates Psss from a BBPM####

list.files()

read.BPPM = function(x = "Data/BPPM/1kcalmol_penalty_data_tables/E01.txt"){
  df = read.delim(x, skip = 1)
  df$PBP = 10^-df$X.log10.Probability.
  Con = file(x)
  ij = as.numeric(readLines(Con)[1])
  close(Con)
  M = matrix(nrow = ij, ncol = ij)
  for (i in 1:nrow(df)){
    M[df$i[i], df$j[i]] = df$PBP[i]
    M[df$j[i], df$i[i]] = df$PBP[i]
  }
  M[which(is.na(M))] = 0
  Pss = c()
  for (i in 1:nrow(M)){
    Pss[i] = 1 - sum(M[i,])
  }
  Pss[which(Pss < 10^-3)] = 10^-3
  output = log10((10^3)*Pss)
  
}

####Function that writes a FASTA and a R2R csv####

write_files = function(x = 4){
  ####Read in data####
  
  df = read.csv(paste("resources/R2easyR_csvs", df.i$Transcript[x], sep = "/"))
  
  ####R2easyR to make csvs####
  
  df = df %>% filter(N %in% df.i$Start[x]:df.i$End[x])
  palette = rev(c("#0D47A1", "#1565C0", "#1976D2", "#1E88E5", "#2196F3", "#42A5F5", "#64B5F6", "#90CAF9", "#BBDEFB", "#E3F2FD"))
  
  #####Make a list of PBPM and read them in####
  
  v.BPPM = paste("Data/BPPM/", list.files("Data/BPPM"), "/", df.i$RNA[x], ".txt", sep = "")
  
  for(i in v.BPPM){
    print(i)
    read.BPPM(i)
  }
  
  l.Pss = lapply(v.BPPM, read.BPPM)
  
  ####Make a list of R2R file prefixes####
  
  v.R2R = paste("Data/R2R_files/", list.files("Data/BPPM"), "/", df.i$RNA[x], sep = "")
  
  for (i in 1:length(v.BPPM)){
    i
    df.i = df %>% select(N, Nucleotide, N.1, N.1.1, BP, N.2, Dotbracket)
    df.i$Reactivity = l.Pss[[i]]
    df.i = r2easyR.color(df.i, palette = palette, manual.scale = c(0,3))
    r2easyR.write(v.R2R[i], df.i, colors = "circles")
  }
  
}

####Run the funtion####

for (i in 1:nrow(df.i)){
  write_files(i)
}
