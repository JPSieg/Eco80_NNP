library(R2easyR)
library(tidyverse)
library(RColorBrewer)

####Read in the index####

df.i = read.csv("resources/main_index.csv")

####Function that writes a FASTA and a R2R csv####

write_files = function(x = 1){
  ####Read in data####
  
  df = read.csv(paste("resources/R2easyR_csvs", df.i$Transcript[x], sep = "/"))
  
  ####R2easyR to make csvs####
  
  df = df %>% filter(N %in% df.i$Start[x]:df.i$End[x])
  palette = rev(c("#BF360C", "#D84315", "#E64A19", "#F4511E", "#FF5722", "#FF7043", "#FF7043", "#FF8A65", "#FFAB91", "#FFCCBC", "#FBE9E7"))
  
  df = r2easyR.color(df, palette = palette, manual.scale = c(0,2))
  df$Colors[which(df$Reactivity >= 2)] = palette[11]
  
  output = paste("Data/R2R_files/", df.i$RNA[x], "_reactivity", sep = "")
  
  r2easyR.write(output, df, colors = "circles")
  
  ####write fasta####
  "Data/FASTAS/{rna}.fasta"
  Lines = c(paste(">", df.i$RNA[x], sep = ""),
            gsub(", ", "", toString(df$Nucleotide)))
  Con = file(paste("Data/FASTAS/", df.i$RNA[x], ".fasta", sep = ""))
  writeLines(Lines, Con)
  close(Con)
}

####Run the funtion####

for (i in 1:nrow(df.i)){
  write_files(i)
}